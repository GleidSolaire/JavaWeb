/**
 * @author 1829799
 *classe que representa um imposto de determinado estado
 */
public class ImpostoSaoPaulo extends Imposto {

	static Double aliquotaEstadual = 0.18;
	
	public ImpostoSaoPaulo(Double valor) {
		super(valor);
	}

	@Override
	public Double calcularImpostoEstadual() {
		return valor * aliquotaEstadual;
	}
	
}
import java.util.Comparator;

/**
 * @author 1829799
 *classe para comparar o valor entre notas fiscas 
 */
public class ComparaValorNota implements Comparator<NotaFiscal> {

	@Override
        /**
         * metodo que ira comparar o valor das notas e retornara em ordem crescente
         */
	public int compare(NotaFiscal o1, NotaFiscal o2) {
		return o1.getValorComImposto().compareTo(o2.getValorComImposto());
	}

}
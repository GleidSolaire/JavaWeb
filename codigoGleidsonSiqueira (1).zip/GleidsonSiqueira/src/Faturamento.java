import java.util.ArrayList;


/**
 * 
 * @author glsiqueira
 *classe que calculo todas as notas fiscais de uma empresa e retorna seu faturamento total
 
 */
public class Faturamento  {
   
	/**
	 * 
	 * @param notas
	 * @retur somanotas
	 * 
	 * esse metodo recebe por parametro uma arraylist de notas e retorna a soma dos elementos contidos nesse array
	 */


public static Double  CalculoFaturamento (ArrayList<NotaFiscal> notas) {
	
	Double somaNotas = 0d;
	
	for (NotaFiscal nota: notas) {
		
		
		somaNotas= somaNotas + nota.getValor();
	}
	
	
	return somaNotas;
}

		
		
			
		
	
	

}
package Bean;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import Entidade.Boleto;
import Servico.ServicoBoleto;
import utils.JSFUtils;

@Named
@RequestScoped
public class BoletoBean {

	

	@EJB
	private ServicoBoleto servicoboleto;

	private Boleto boleto;
    
	private  List <Boleto> boletos;
	
	
	public List<Boleto> getBoletos() {
		if (this.boletos == null) {
			this.boletos = this.servicoboleto.listar();
		}
		return boletos;
	
	}
	
	public BoletoBean() {
		this.boleto = new Boleto();
	}

	public void salvarBoleto() {
		this.servicoboleto.CadastrarBoleto(boleto);
		this.boleto = new Boleto();
		JSFUtils.enviarMensagemDeSucesso("Boleto cadastrado com sucesso!");
	}

	public Boleto getBoleto() {
		return boleto;
	}

	public void setBoleto(Boleto boleto) {
		this.boleto = boleto;
	}

	public List<Boleto> listarBoletos() {
		return this.servicoboleto.listar();
	}

	public void excluirBoleto(Boleto boleto) {
	
		try {
			this.servicoboleto.Excluir(boleto);
			JSFUtils.enviarMensagemDeAtencao("boleto deletado!!");
			
		}catch (Exception e) {
			JSFUtils.enviarMensagemDeAtencao(e.getMessage());
		}
		}
	
	
}

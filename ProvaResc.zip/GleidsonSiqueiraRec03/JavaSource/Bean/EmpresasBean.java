package Bean;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import Entidade.Empresa;
import Servico.ServicoEmpresa;
import utils.JSFUtils;

@Named
@RequestScoped
public class EmpresasBean {

	@EJB
private ServicoEmpresa servicoempresa;
	
private Empresa empresa;
	


	public EmpresasBean() {
      this.setEmpresa( new Empresa());
	}

	
public void CadastrarEmpresa () {
	
	this.servicoempresa.CadastrarEmpresa(empresa);
	JSFUtils.enviarMensagemDeSucesso("Empresa cadastrada!");
	this.empresa = new Empresa();
	
}
	
	public ServicoEmpresa getServicoempresa() {
		return servicoempresa;
	}

	public void setServicoempresa(ServicoEmpresa servicoempresa) {
		this.servicoempresa = servicoempresa;
	}

	public Empresa getEmpresa() {
		return empresa;
	}

	public void setEmpresa(Empresa empresa) {
		this.empresa = empresa;
	}
	
	
}

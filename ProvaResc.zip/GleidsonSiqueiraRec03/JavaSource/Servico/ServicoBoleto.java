package Servico;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.GET;

import Entidade.Boleto;
import Entidade.Empresa;


@Stateless
public class ServicoBoleto {

	
	@PersistenceContext
private EntityManager em;

	
	
	
public void CadastrarBoleto (Boleto boleto) {
	
	this.em.persist(boleto);
}
	

public void Excluir (Boleto boleto)  throws Exception {
	
	if (boleto.isPago() != true) {
		throw new Exception("Nao � possivel deletar boletos pagos");
	
		
	} 

	
	this.em.remove(this.em.merge(boleto));
	
}


@GET
public List<Empresa> listarBoletoEmpresas(Boleto boleto) {
	return this.em.createQuery("From Boleto v WHERE v.boleto=:p1", Empresa.class).setParameter("p1", boleto)
			.getResultList();
}

public List<Boleto> listar() {
	return this.em.createQuery("FROM Boleto b", Boleto.class).getResultList();
}



}

package Servico;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import Entidade.Empresa;

@Stateless
public class ServicoEmpresa {

	
	@PersistenceContext
	private EntityManager em;
	
	
	public void CadastrarEmpresa (Empresa empresa) {
		this.em.persist(empresa);
	}
}

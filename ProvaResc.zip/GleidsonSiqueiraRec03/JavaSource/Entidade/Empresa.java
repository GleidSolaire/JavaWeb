package Entidade;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;

@Entity
public class Empresa {

	public Empresa() {
		
	}
	@javax.persistence.Id
	@SequenceGenerator(name = "EMPRESAS_SEQUENCIAL", sequenceName = "NUM_SEQ_EMPRESAS", allocationSize = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EMPRESAS_SEQUENCIAL")
	private Integer Id;
	
	@NotBlank
	private String cnpj;
	
	@NotBlank
	private String ramo;

	@NotBlank
	private String nome;
	
	@OneToMany(mappedBy = "empresa", fetch = FetchType.LAZY)
	private List<Boleto> boletos;
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getCnpj() {
		return cnpj;
	}

	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	public String getRamo() {
		return ramo;
	}

	public void setRamo(String ramo) {
		this.ramo = ramo;
	}
	
	
}

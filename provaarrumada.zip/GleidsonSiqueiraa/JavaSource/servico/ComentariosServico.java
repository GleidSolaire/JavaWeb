package servico;

import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import entidade.Tipo;
import entidade.comentarios;

@Stateless
public class ComentariosServico {

	@PersistenceContext
	private EntityManager em;
	
	
	public void CadastrarComentario (comentarios comentario) 
	{
	
		comentario.setCurtidas(0);
		comentario.setDatacomentario(new Date());
	 this.em.persist(comentario);
	 
	
    }
	
	
	public void curtir(comentarios comentario) {
		comentario.curtir();;
		this.em.merge(comentario);
	}
	
	
	public void Excluir (comentarios comentario)  throws Exception {
		
		if (comentario.getCurtidas() > 0) {
			throw new Exception("Nao � possivel deletar comentarios curtidos");
		
			
		} 
//		if(!comentario.getTipo().getDescricao().equalsIgnoreCase("Normal")) {
		if(!comentario.getTipo().equals(Tipo.Normal)) {
			throw new Exception("N�o � possivel excluir comentarios desse tipo");
		}
		
		
		this.em.remove(this.em.merge(comentario));
		
	}
	
	
	
	
	
	public List<comentarios> listar() {
		return this.em.createQuery("FROM comentarios m", comentarios.class).getResultList();
	}
}
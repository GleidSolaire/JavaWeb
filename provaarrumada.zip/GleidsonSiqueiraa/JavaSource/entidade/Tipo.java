package entidade;

public enum Tipo {

		
		Urgente("Urgente"),
		Importante("Importante"),
		Normal("Normal");
	
		
		private String descricao;
		
		private Tipo(String descricao) {
			this.descricao = descricao;
		}

		public String getDescricao() {
			return descricao;
		}

		public void setDescricao(String descricao) {
			this.descricao = descricao;
		}

	}

	


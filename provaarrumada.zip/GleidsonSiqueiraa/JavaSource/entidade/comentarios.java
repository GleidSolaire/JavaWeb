package entidade;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
public class comentarios {

	@Id
	@SequenceGenerator(name = "COMENTARIOS_SEQUENCIAL", sequenceName = "NUM_SEQ_COMENTARIOS", allocationSize = 0)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COMENTARIOS_SEQUENCIAL")
	private Integer id;
	
	@NotNull
	@NotBlank
	private String nome;
	@NotNull
	@NotBlank
@Length(min = 10, max = 140, message = "O comentario precisa ter entre 10 e 140 caracteres")
	private String comentario;
	
	

	@NotNull
	@Enumerated(value = EnumType.STRING)
	private Tipo tipo;
	
	
	public comentarios() {
		
	}
	

	public void curtir() {
		this.curtidas++;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	public Date getDatacomentario() {
		return datacomentario;
	}
	public void setDatacomentario(Date datacomentario) {
		this.datacomentario = datacomentario;
	}
	public Integer getCurtidas() {
		return curtidas;
	}
	public void setCurtidas(Integer curtidas) {
		this.curtidas = curtidas;
	}
	public Tipo getTipo() {
		return tipo;
	}


	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	private Date datacomentario;
	private Integer curtidas;
}

package modelo;

import java.util.List;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

import entidade.comentarios;
import servico.ComentariosServico;
import utils.JSFUtils;

@Named
@RequestScoped
public class ComentariosModelo {
	
	@EJB
	private ComentariosServico comentarioservico;
	
	private comentarios comentario;
	
	public ComentariosModelo() {
this.setComentario( new comentarios ());
	}

	public void Cadastrar () {
		
		this.comentarioservico.CadastrarComentario(comentario);
		JSFUtils.enviarMensagemDeSucesso("comentario cadastrado com sucesso");
		this.comentario = new comentarios();
	}
	
	
	
	public void Curtir (comentarios comentario) {
		
		this.comentarioservico.curtir(comentario);
		JSFUtils.enviarMensagemDeSucesso("Comentario Curtido ");
	}
	
	
	
	public void Excluir (comentarios comentario) {
		try {
		this.comentarioservico.Excluir(comentario);
		JSFUtils.enviarMensagemDeAtencao("Comentario deletado!!");
		
	}catch (Exception e) {
		JSFUtils.enviarMensagemDeAtencao(e.getMessage());
	}
	}
	
	public List<comentarios>  listacomentarios () {
		return this.comentarioservico.listar();
		
	}
	
	
	public ComentariosServico getComentarioservico() {
		return comentarioservico;
	}

	public void setComentarioservico(ComentariosServico comentarioservico) {
		this.comentarioservico = comentarioservico;
	}

	public comentarios getComentario() {
		return comentario;
	}

	public void setComentario(comentarios comentario) {
		this.comentario = comentario;
	}
	
	
}

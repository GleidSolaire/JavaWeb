package modelo;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;

import entidade.Tipo;




	@Named
	@ApplicationScoped
	public class TipoBean {

		public Tipo[] listarCombustiveis() {
			return Tipo.values();
		}

	}


